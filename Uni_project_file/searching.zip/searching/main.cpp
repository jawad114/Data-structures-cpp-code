#include <iostream>
#include"head.h"
using namespace::std;
int main(int argc, char** argv) {
	searching s;
	int A[5]={34,55,76,87};
	s.search(55);
	return 0;
}
