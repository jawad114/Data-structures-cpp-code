class searching{
	public:
		int i,j;
	searching *next;
		int A[5]={34,55,76,87};	
		void search(int );
};
